-- phpMyAdmin SQL Dump
-- version 4.0.10.14
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Jun 13, 2016 at 11:07 AM
-- Server version: 5.6.30
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lokkeshw_csc`
--

-- --------------------------------------------------------

--
-- Table structure for table `appoinments`
--

CREATE TABLE IF NOT EXISTS `appoinments` (
  `patient_id` varchar(50) NOT NULL,
  `doctor` varchar(500) NOT NULL,
  `date` varchar(500) NOT NULL,
  `status` varchar(1000) NOT NULL DEFAULT 'Pending',
  `tid` int(100) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `appoinments`
--

INSERT INTO `appoinments` (`patient_id`, `doctor`, `date`, `status`, `tid`) VALUES
('125', 'Dr Lokkesh( Chiropractors )', '06/14/2016', '', 5),
('123', 'Dr Siva Ganesh ( Oncologist )', '06/14/2016', 'Pending', 6),
('1234', 'Dr Siva - Onco ', '06/22/2016', 'Pending', 21),
('1234', 'Dr Sabastein - Gastro ', '06/10/2016', 'Pending', 22),
('1234', 'Dr Angali - Epidem ', '06/09/2016', 'Pending', 17),
('1234', 'Dr Popwell - Cardio ', '06/08/2016', 'Pending', 18),
('1234', 'Dr RameshKumar - Anesthe ', '06/04/2016', 'Pending', 19),
('1234', 'Dr Siva - Onco ', '06/15/2016', 'Pending', 20);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `patient_id` varchar(100) NOT NULL,
  `feedback` varchar(10000) NOT NULL,
  `tid` int(100) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`patient_id`, `feedback`, `tid`) VALUES
('1234/', 'Good Service and On Time Delivery System.', 1),
('1234/', 'Good service. Need some updates.', 2),
('1234', 'Excellent service. ', 3),
('1234', 'Good healt care facilities.', 4),
('1234', 'Good healtcare services.', 5);

-- --------------------------------------------------------

--
-- Table structure for table `mrecords`
--

CREATE TABLE IF NOT EXISTS `mrecords` (
  `patient_id` varchar(50) NOT NULL,
  `doctor` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `summary` varchar(10000) NOT NULL,
  `tid` int(100) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `mrecords`
--

INSERT INTO `mrecords` (`patient_id`, `doctor`, `date`, `summary`, `tid`) VALUES
('1234', 'Dr Ramana', '05/12/2015', 'http://lokkeshwaran.cu.ma/csccoin/samplereport.html', 1),
('1234', 'Dr Ramesh', '22/05/2016', 'http://lokkeshwaran.cu.ma/csccoin/samplereport.html', 2);

-- --------------------------------------------------------

--
-- Table structure for table `refill`
--

CREATE TABLE IF NOT EXISTS `refill` (
  `patient_id` varchar(200) NOT NULL,
  `tablet` varchar(500) NOT NULL,
  `qt` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `tid` int(100) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `refill`
--

INSERT INTO `refill` (`patient_id`, `tablet`, `qt`, `price`, `tid`) VALUES
('1234', 'crocin', '2', '50', 1),
('1234', 'mox500', '3', '200', 2);

-- --------------------------------------------------------

--
-- Table structure for table `refillorders`
--

CREATE TABLE IF NOT EXISTS `refillorders` (
  `patient_id` varchar(500) NOT NULL,
  `amount` varchar(500) NOT NULL,
  `status` varchar(500) NOT NULL,
  `tid` int(100) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `refillorders`
--

INSERT INTO `refillorders` (`patient_id`, `amount`, `status`, `tid`) VALUES
('1234', '250', '', 1),
('1234', '250', '', 2),
('1234', '250', '', 3),
('1234', '250', '', 4),
('1234', '250', '', 5);

-- --------------------------------------------------------

--
-- Table structure for table `symptoms`
--

CREATE TABLE IF NOT EXISTS `symptoms` (
  `patient_id` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `symptoms` varchar(10000) NOT NULL,
  `tid` int(100) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `symptoms`
--

INSERT INTO `symptoms` (`patient_id`, `date`, `time`, `symptoms`, `tid`) VALUES
('111', '06/08/2016', '1:00am', 'fever', 1),
('1234', '06/15/2016', '4:00am', 'Fever with cold', 2),
('1234', '06/15/2016', '2:30am', 'Dengu fever.', 3),
('1234', '06/15/2016', '5:45am', 'Cold with cough.', 4),
('1234', '06/01/2016', '1:00am', 'Fever with cold.', 5);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `name` text NOT NULL,
  `email` text NOT NULL,
  `passwd` text NOT NULL,
  `id` int(100) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `email`, `passwd`, `id`) VALUES
('Admin', 'admin@hc.com', 'csc', 6);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(70) NOT NULL,
  `password` varchar(40) NOT NULL,
  `patient_id` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `vote` varchar(100) NOT NULL,
  `regid` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`patient_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `patient_id`, `created_at`, `updated_at`, `vote`, `regid`) VALUES
(1, 'mom', 'bd1d7b0809e4b4ee9ca307aa5308ea6f', 'mom', '2016-06-11 19:40:31', '2016-06-11 19:40:31', '', 'APA91bFkpgLHhlpTeraHiWYfM58jXg6Y1oDt4MBVI4NSA52b6z5VvrpPtEi8f9uatjrUSndTwovbBQaaUyfih10s5Zg85rsOLdST6aNIVsTWIwFEL2xRhaSzNy7YkElpg0i-GURsPR03'),
(2, 'ok', 'f19852e51c1ab671bfd8b9f4a9dc92f9', 'lok', '2016-06-11 19:54:06', '2016-06-11 19:54:06', '', 'APA91bFkpgLHhlpTeraHiWYfM58jXg6Y1oDt4MBVI4NSA52b6z5VvrpPtEi8f9uatjrUSndTwovbBQaaUyfih10s5Zg85rsOLdST6aNIVsTWIwFEL2xRhaSzNy7YkElpg0i-GURsPR03'),
(3, 'mm', 'b3cd915d758008bd19d0f2428fbb354a', 'mm', '2016-06-11 21:56:46', '2016-06-11 21:56:46', '', 'APA91bFkpgLHhlpTeraHiWYfM58jXg6Y1oDt4MBVI4NSA52b6z5VvrpPtEi8f9uatjrUSndTwovbBQaaUyfih10s5Zg85rsOLdST6aNIVsTWIwFEL2xRhaSzNy7YkElpg0i-GURsPR03'),
(4, 'lokkesh', 'f19852e51c1ab671bfd8b9f4a9dc92f9', '1234', '2016-06-12 00:50:46', '2016-06-12 00:50:46', '', 'APA91bFkpgLHhlpTeraHiWYfM58jXg6Y1oDt4MBVI4NSA52b6z5VvrpPtEi8f9uatjrUSndTwovbBQaaUyfih10s5Zg85rsOLdST6aNIVsTWIwFEL2xRhaSzNy7YkElpg0i-GURsPR03'),
(5, 'csc_test', 'ee7ddfa19482e219fb5021ec30bd975c', '1000', '2016-06-13 00:51:58', '2016-06-13 00:51:58', '', 'APA91bFkpgLHhlpTeraHiWYfM58jXg6Y1oDt4MBVI4NSA52b6z5VvrpPtEi8f9uatjrUSndTwovbBQaaUyfih10s5Zg85rsOLdST6aNIVsTWIwFEL2xRhaSzNy7YkElpg0i-GURsPR03');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
