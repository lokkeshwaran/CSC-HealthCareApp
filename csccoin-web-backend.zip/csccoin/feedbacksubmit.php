
<html>
<head>
    <style>
        .myButton {
        background-color:#44c767;
        -moz-border-radius:31px;
        -webkit-border-radius:31px;
        border-radius:31px;
        display:inline-block;
        cursor:pointer;
        color:#ffffff;
        font-family:Arial;
        font-size:17px;
        padding:12px 24px;
        text-decoration:none;
        text-shadow:0px 1px 0px #2f6627;
        }
        .myButton:hover {
        background-color:#bd2a78;
        }
        .myButton:active {
        position:relative;
        top:1px;
        }
		
		.button{
 text-decoration:none; 
 text-align:center; 
 padding:11px 32px; 
 border:none; 
 -webkit-border-radius:17px;
 -moz-border-radius:17px; 
 border-radius: 17px; 
 font:18px Arial, Helvetica, sans-serif; 
 font-weight:bold; 
 color:#f2f2f2; 
 background-color:#de6266; 
 background-image: -moz-linear-gradient(top, #de6266 0%, #b01131 100%); 
 background-image: -webkit-linear-gradient(top, #de6266 0%, #b01131 100%); 
 background-image: -o-linear-gradient(top, #de6266 0%, #b01131 100%); 
 background-image: -ms-linear-gradient(top, #de6266 0% ,#b01131 100%); 
 filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b01131', endColorstr='#b01131',GradientType=0 ); 
 background-image: linear-gradient(top, #de6266 0% ,#b01131 100%);   
 -webkit-box-shadow:inset 0px 0px 1px #ffffff;  -moz-box-shadow:inset 0px 0px 1px #ffffff;  box-shadow:inset 0px 0px 1px #ffffff;  
 opacity:0.94; 
 -ms-filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=94); 
 filter: alpha(opacity=94); 
  }
  
  
  
  th, td {
    text-align: center;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #4CAF50;
    color: white;
}
    </style>
  
</head>

<body style="text-align:justify;color:black;">




<?php

require_once 'include/user.php';
include_once 'include/db.php';


if(isset($_POST["feed"])){
$feed=$_POST["feed"];
}
if(isset($_POST["pid"])){
$pid=$_POST["pid"];
}

if(!empty($feed) && !empty($pid)){

$servername = "localhost";
$username = "lokkeshw_csc";
$password = "csc123";
$dbname = "lokkeshw_csc";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO feedback (patient_id, feedback)
VALUES ('$pid','$feed')";

if ($conn->query($sql) === TRUE) {
    echo "<br><br><br><br><br><br><p align='center'>  <font size='5px' color='#264d73'><b> Feedback Submitted Successfully.</font> </p>";
	
	echo"<p align='center'><img src='stick.png' alt='success' style='width:150px;height:150px;'></p>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();



}
else{

 echo "<br><br><br><br><br><br><p align='center'> <font size='5px' color='#ff0000'><b> Not Valid Entries<br>Try Again. !!</font> </p>";
// echo"<p align='center'><img src='stick.png' alt='success' style='width:150px;height:150px;'></p>";


}








?>

</body>
</html>