<?php

require_once 'include/user.php';

$username = "";
$password = "";
$patient_id = "";
$vote="";
$regid="";

if(isset($_POST['username'])){
	$username = $_POST['username'];
}
if(isset($_POST['password'])){
    $password = $_POST['password'];
}
if(isset($_POST['patient_id'])){
	$patient_id = $_POST['patient_id'];
	
}
if(isset($_POST['vote'])){
    $vote = $_POST['vote'];
}
if(isset($_POST['regid'])){
	$regid = $_POST['regid'];
}

// Instance of a User class
$userObject = new User();

// Registration of new user
if(!empty($username) && !empty($password) && !empty($patient_id)&& !empty($regid)){
	$hashed_password = md5($password);
	$json_registration = $userObject->createNewRegisterUser($username, $hashed_password, $patient_id,$regid);
	
	echo json_encode($json_registration);
}

// User Login
if(!empty($patient_id) && !empty($password) && empty($username)){
	$hashed_password = md5($password);	
    $json_array = $userObject->loginUsers($patient_id, $hashed_password);

    echo json_encode($json_array);
}

//voteedit
if(!empty($patient_id) && !empty($vote) && empty($username) && empty($password)){
		
    $json_array = $userObject->voteedit($patient_id, $vote);

    echo json_encode($json_array);
}



?>