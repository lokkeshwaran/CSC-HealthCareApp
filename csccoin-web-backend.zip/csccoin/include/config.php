<?php

 define("DB_HOST", "localhost");
 define("DB_USER", "lokkeshw_csc");
 define("DB_PASSWORD", "csc123");
 define("DB_NAME", "lokkeshw_csc");

?>