<?php

include_once 'db.php';

class User{
	
	private $db;
	private $db_table = "users";
	
	public function __construct(){
		$this->db = new DbConnect();
	}
	
	public function isLoginExist($patient_id, $password){		
				
		$query = "select * from " . $this->db_table . " where patient_id = '$patient_id' AND password = '$password' Limit 1";
		$result = mysqli_query($this->db->getDb(), $query);
		if(mysqli_num_rows($result) > 0){
			mysqli_close($this->db->getDb());
			return true;
		}		
		mysqli_close($this->db->getDb());
		return false;		
	}
	
	public function createNewRegisterUser($username, $password, $patient_id, $regid){
		$json = array();
		$query = "insert into users (username, password, patient_id, created_at, updated_at, regid) values ('$username', '$password', '$patient_id', NOW(), NOW(), '$regid')";
		$inserted = mysqli_query($this->db->getDb(), $query);
		if($inserted == 1){
			$json['success'] = 1;									
		}else{
			$json['success'] = 0;
		}
		mysqli_close($this->db->getDb());
		return $json;
	}
	
	public function loginUsers($patient_id, $password){
			
		$json = array();
		$canUserLogin = $this->isLoginExist($patient_id, $password);
		if($canUserLogin){
			$json['success'] = 1;
		}else{
			$json['success'] = 0;
		}
		return $json;
	}

	
	
public function voteedit($patient_id, $vote){
			
		$query = "update users set vote='$vote' where patient_id='$patient_id'";
		$inserted = mysqli_query($this->db->getDb(), $query);
		if($inserted == 1){
			$json['success'] = 1;									
		}else{
			$json['success'] = 0;
		}
		mysqli_close($this->db->getDb());
		return $json;
	}
	
		public function getAllUsers() {
        $result = mysqli_query($this->db->getDb(),"select * FROM users");
        return $result;
    }
	
	public function getGCMRegID($patient_idID){
	echo $patient_idID;
		 $result = mysqli_query($this->db->getDb(),"SELECT regid FROM users WHERE patient_id = '$patient_idID'");
		 return $result;
	}
	
	
}


?>