

<html>

<head>

<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
    
    <!-- Load jQuery JS -->
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <!-- Load jQuery UI Main JS  -->
    <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    
    <!-- Load SCRIPT.JS which will create datepicker for input field  -->
    <script src="script.js"></script>
	<link rel="stylesheet" href="stylesheet.css" />
	
	  
	  
  
</head>

<body>

<?php

error_reporting( E_ALL );
$pid=$_GET["pid"];

?>
<form method="post" action="feedbacksubmit.php">

<hr>
<p align="center"><font size='4px' color='#264d73'><b>
Help / Feedbacks</b>
</p>
<hr>
<p align="center">
<textarea align="center" name="feed" placeholder="Your Feedbak Here...." rows="10" cols="30">
</textarea>
<br>
<?php 
	echo "
	<input type='hidden' name='pid' value={$pid}> ";
	?>
<input type=submit class="btn" value="Submit feedback"></input>
	
</p>
</body>

</html>
