<html>
<head><title>View Patients</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<style>
body {
  font: normal medium/1.4 sans-serif;
}
div.greetblock, div.serverresponse {
  border-collapse: collapse;
  width: 60%;
  margin-left: auto;
  margin-right: auto;
  align: center;
}
tr > td {
  padding: 0.25rem;
  text-align: center;
  border: 1px solid #ccc;
}
tr:nth-child(even) {
  background: #fff;
  
}
tr:nth-child(odd) {
  background: #FA9A8B;
  color: #fff;
}
tr#header{
background: #F78371;
}

div#norecord{
margin-top:10px;
width: 15%;
margin-left: auto;
margin-right: auto;
}
input,select{
cursor: pointer;
}
img{
margin-top: 10px;
height: 200px;
width: 300px;
}
select{
width: 200px
}
div.leftdiv{
width: 45%;
padding: 0 10px;
float: left;
border: 1px solid #ccc;
margin: 5px;
height: 320px;
text-align:center;
}
div.rightdiv{
width: 45%;
padding: 0 10px;
float: right;
border: 1px solid #ccc;
margin: 5px;
height: 320px;
text-align:center;
}
hidediv{
display: none;
}
p.header{
height: 40px;
background-color: #EB5038;
padding: 10px;
color: #fff;
text-align:center;
margin: 0;
margin-bottom: 10px;
}
textarea{
font-size: 25px;
font-weight: bold;
}

</style>
<script>
function sendMsg(){
var msgLength = $.trim($("textarea").val()).length;
var checkedCB = $("input[type='checkbox']:checked").length;
if( checkedCB == 0){
	alert("You must select atleast one User to send message");
}else if(msgLength == 0){
	alert("You left the message field blank, please fill it");
}else{
	var formData = $(".wrapper").find("input").serialize() + "&imgurl="+ $("#festival").val() + "&message=" + $("textarea").val();	
	$.ajax({type: "POST",data: formData, url: "processmessage.php", success:function(res){
		$(".greetblock").slideUp(1000);
		$(".serverresponse").prepend(res).hide().fadeIn(2000);
	}});
}
}
$(function(){
	$(".serverresponse").hide()
	$("input[type='checkbox']").click(function(){
		if($(this).is(':checked')){
			$(this).parent().css("border","3px solid red");
		}else{
			$(this).parent().css("border","0px");
		}
	});
	
	$("div.leftdiv, div.rightdiv").hover(function(){
		$(this).css("background","#FAFAFA");
	},function(){
		$(this).css("background","#fff");
	});
	
	$("#festival").change(function(){
		$("img").attr("src",$(this).val());
	});
	
	$("#sendmsg").click(function(){
		$(".serverresponse").fadeOut(300,function(){
			$(".greetblock").fadeIn(1000);
		});		
	});
});


var lastChecked = null;
    
            $(document).ready(function() {
                var $chkboxes = $('.chkbox');
                $chkboxes.click(function(e) {
                    if(!lastChecked) {
                        lastChecked = this;
                        return;
                    }
    
                    if(e.shiftKey) {
                        var start = $chkboxes.index(this);
                        var end = $chkboxes.index(lastChecked);

                        $chkboxes.slice(Math.min(start,end), Math.max(start,end)+ 1).prop('checked', lastChecked.checked);
    
                    }
    
                    lastChecked = this;
                });
            });
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
</head>
<body>
<?php
 require_once 'include/user.php';

    $db = new User();
    $users = $db->getAllUsers();
	
	   $no_of_users = mysqli_num_rows($users);
	  
    
    if ($no_of_users > 0) {
	
?>

<div class="greetblock">
<div class="leftdiv">
<p class="header">Select patient_ID to whom you want to send a Notification.
</p>
<br>
 SELECT ALL <input type="checkbox" value="SELECT ALL"  onclick="for(c in document.getElementsByName('sendmsg[]')) document.getElementsByName('sendmsg[]').item(c).checked = this.checked">
<br>
<table>
<tr id="header"><td>Id</td><td>Patient_ID</td><td>Send Message?</td></tr>
<?php
    while ($row = mysqli_fetch_assoc($users)) {
?> 
<tr>
<td><span><?php echo $row["id"] ?></span></td>
<td><span><?php echo $row["patient_id"] ?></span></td>
<td><span class="wrapper"><input type="checkbox" class="chkbox" name="sendmsg[]" value="<?php echo $row["patient_id"] ?>"/></span></td>
</tr>
<?php } ?>
</table>
</div>

<div class="rightdiv">
<p class="header">Type your message
</p>
<textarea cols="15" rows="5" value="txtarea">

</textarea>
</div>
<div class="rightdiv">
<p class="header">Send your Notification to your Patients
</p>
<center>
<button onclick="sendMsg()">Send Notification</button>
</center>
</div>
</div>
<div class="serverresponse hidediv">
<center><button id="sendmsg">Send Notification Again</button></center>
</div>
<?php }else{ ?>
<div id="norecord">
No records in MySQL DB
</div>
<?php } ?>

</body>
</html>