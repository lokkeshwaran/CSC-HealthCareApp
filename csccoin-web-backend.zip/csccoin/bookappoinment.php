

<html>

<head>

<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
    
    <!-- Load jQuery JS -->
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <!-- Load jQuery UI Main JS  -->
    <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    
    <!-- Load SCRIPT.JS which will create datepicker for input field  -->
    <script src="script.js"></script>
	<link rel="stylesheet" href="stylesheet.css" />
	
	  
	  
  
</head>

<body>

<?php

error_reporting( E_ALL );
$pid=$_GET["pid"];

?>
<form method="post" action="appoinmentsuccess.php">
<label>
    <select name="doctor">
        <option selected> Choose Your Doctor </option>
        <option value="Dr RameshKumar - Anesthe ">Dr Ramesh Kumar ( Anesthesiology )</option>
        <option value="Dr Popwell - Cardio " >Dr Popwell ( Cardiologists )</option>
		<option value="Dr Lokkesh - Chiro ">Dr Lokkesh( Chiropractors )</option>
		<option value="Dr ReddyRoa - Dermato ">Dr Reddy Roa ( Dermatologists )</option>
		<option value="Dr Angali - Epidem ">Dr Angali ( Epidemiologist/Infections )</option>
		<option value="Dr Sabastein - Gastro ">Dr Sabastein ( Gastroenterologists )</option>
		<option value="Dr Hussain - Neuro ">Dr Hussain ( Neurologist )</option>
		<option value="Dr Siva - Onco ">Dr Siva Ganesh ( Oncologist )</option>
		<option value="Dr Segutuvan - Ortho ">Dr Segutuvan ( Orthopedics )</option>
	    <option value="Dr Seetha - Pedia ">Dr Seethalakshmi ( Pediatricians )</option>
    </select>
	
</label>

<br>
	<br>
	<b><p align="center">Appoinment Date</p></b>
	
	<input type="text" name="date" id="datepicker">
	<?php 
	echo "
	<input type='hidden' name='pid' value=$pid > ";
	?>
	
	<br>
	<br>
	<br>
	<input type=submit class="btn" value="Book Appoinment"></input>
	
	<br>

</body>

</html>
