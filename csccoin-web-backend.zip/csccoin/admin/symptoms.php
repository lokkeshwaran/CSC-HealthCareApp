<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .myButton {
        background-color:#44c767;
        -moz-border-radius:31px;
        -webkit-border-radius:31px;
        border-radius:31px;
        display:inline-block;
        cursor:pointer;
        color:#ffffff;
        font-family:Arial;
        font-size:17px;
        padding:12px 24px;
        text-decoration:none;
        text-shadow:0px 1px 0px #2f6627;
        }
        .myButton:hover {
        background-color:#bd2a78;
        }
        .myButton:active {
        position:relative;
        top:1px;
        }
		
		.button{
 text-decoration:none; 
 text-align:center; 
 padding:11px 32px; 
 border:none; 
 -webkit-border-radius:17px;
 -moz-border-radius:17px; 
 border-radius: 17px; 
 font:18px Arial, Helvetica, sans-serif; 
 font-weight:bold; 
 color:#f2f2f2; 
 background-color:#de6266; 
 background-image: -moz-linear-gradient(top, #de6266 0%, #b01131 100%); 
 background-image: -webkit-linear-gradient(top, #de6266 0%, #b01131 100%); 
 background-image: -o-linear-gradient(top, #de6266 0%, #b01131 100%); 
 background-image: -ms-linear-gradient(top, #de6266 0% ,#b01131 100%); 
 filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b01131', endColorstr='#b01131',GradientType=0 ); 
 background-image: linear-gradient(top, #de6266 0% ,#b01131 100%);   
 -webkit-box-shadow:inset 0px 0px 1px #ffffff;  -moz-box-shadow:inset 0px 0px 1px #ffffff;  box-shadow:inset 0px 0px 1px #ffffff;  
 opacity:0.94; 
 -ms-filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=94); 
 filter: alpha(opacity=94); 
  }

 
  th, td {
    text-align: center;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #4CAF50;
    color: white;
}

table{table-layout:fixed;width:100%;}
tbody>tr>*:nth-last-child(2)~*{ width:50%}
tbody>tr>*:nth-last-child(3)~*{ width:33.3%}
tbody>tr>*:nth-last-child(4)~*{ width:25%}
    </style>
	
	
  
</head>


<body style="text-align:justify;color:black;">
<hr>
<p align='center'>
<font size=6px>Patient Symptoms</font>
</p>
<hr>
<hr>
<p align='center'>
<A HREF="javascript:history.go(0)">Click to Refresh</A>
</p>
<hr>
<p align="center">


<?php

require_once '../include/user.php';
include_once '../include/db.php';


if(isset($_POST["pid"])){
$pid=$_POST["pid"];
}

if(!empty($pid)){

$servername = "localhost";
$username = "lokkeshw_csc";
$password = "csc123";
$dbname = "lokkeshw_csc";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "select * from symptoms where patient_id='$pid'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
	echo"<table border='0' align='center'><thead>";
		echo"<tr><th>Patients_ID</th><th>Date</th><th>Time</th><th>Symptoms</th></tr></thead><tbody>";
    while($row = $result->fetch_assoc()) {
	    $temp=$row["summary"];
	   echo"  <tr>";
        echo "<td> " . $row["patient_id"]. "</td><td>" . $row["date"]. "</td><td>" . $row["time"]."</td><td>" . $row["symptoms"]."</td>";
		echo"</tr>";
    }
	echo"</tbody></table>";
} else {
    echo "<p align='center'><font size='4px' color='#264d73'>No Symptoms Record Found</p>";
}

}


$conn->close();



?>
</p>
</body>
</html>