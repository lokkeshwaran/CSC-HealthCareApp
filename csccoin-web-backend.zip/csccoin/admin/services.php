<html lang="en">
<head>
  <meta charset="utf-8">
  <title>HC++ - Welcome</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

	
	
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">

  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-114-precomposed.png">
  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72-precomposed.png">
  <link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon-57-precomposed.png">
  <link rel="shortcut icon" href="img/favicon.png">
  
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/scripts.js"></script>
</head>

<body>

<?php
$host="localhost";
$username="lokkeshw_csc";
$password="csc123";
$db_name="lokkeshw_csc";
$tbl_name="user";
$conn = mysql_connect("$host", "$username", "$password")or die("cannot connect");
mysql_select_db("$db_name")or die("cannot select DB");
$uemail=$_POST['email'];
$upasswd=$_POST['passwd'];
$flag1=0;
$flag2=0;

$sql1="select * from user where email ='$uemail'";

$result1=mysql_query($sql1);
if (!$result1) {
    die('Invalid query1: ' . mysql_error());
}

$count1=mysql_num_rows($result1);
if($count1 == 1)
{ $flag1=1;}

$sql2="select * from user where email ='$uemail' and passwd='$upasswd'";
$result2=mysql_query($sql2);
if (!$result2) {
    die('Invalid query2: ' . mysql_error());
}

$count2=mysql_num_rows($result2);
if($count2 == 1)
{ $flag2=1;}

?>
<div class="container">
	<div class="row clearfix">
		<div class="col-md-12 column">
		
<?php

if($flag2==1)
{
?>
<div class="row clearfix">
				<div class="col-md-3 column">
				</div>
				<div class="col-md-6 column">
				</div>
				<div class="col-md-3 column">
					 <button type="button" class="btn btn-danger btn-block" onclick="location.href = 'login.html';">Logout</button>
				</div>
			</div>
			<br><br>
			<div class="jumbotron">
				<h1>
				<?php 
                       while($row = mysql_fetch_array($result1, MYSQL_ASSOC))
                         {
                            echo "Welocome ...  {$row['name']}  !!! ";
                         }
   
                 ?>
				</h1>
			</div> 
		 
			<button type="button" class="btn btn-primary btn-lg btn-block active">HEALTHCARE++ SERVICES</button><br><br><br>
			
			<p align="center">
			<div class="row clearfix">
				<div class="col-md-3 column">
				<button type="button" class="btn btn-danger btn-block" onclick="location.href = 'viewmrecords.html';">View Patient Records</button>
				</div>
				<div class="col-md-3 column">
					 <button type="button" class="btn btn-danger btn-block" onclick="location.href = 'viewsymptoms.html';">View Patient Symptoms</button>
				</div>
				<div class="col-md-3 column">
				<button type="button" class="btn btn-danger btn-block" onclick="location.href = 'appoinments.php';">Booked Appoinments</button>
				</div>
				<div class="col-md-3 column">
				<button type="button" class="btn btn-danger btn-block" onclick="location.href = 'rorders.php';">Refills Orders</button>
				</div>
			</div> 
			</p><br><br>
			<div class="row clearfix">
				<div class="col-md-6 column">
					 <button type="button" class="btn btn-danger btn-block btn-default" onclick="location.href = '../viewusers.php';">Send a Notification</button>
				</div>
				<div class="col-md-6 column">
					 <button type="button" class="btn btn-danger btn-block" onclick="location.href = 'feedbacks.php';">Patients Feedback</button>
				</div>
			</div>
			


<?php }

else if($flag1==0)
{
   ?>
   	<div class="jumbotron">
				<h1>
					Session Invalid ...
				</h1>
			</div> 
			<div>
					 <button type="button" class="btn btn-danger btn-block" onclick="location.href = 'login.html';" >Login Again</button>
				</div>
<?php

}
else
{
?>	
<div class="jumbotron">
				<h1>
					Invalid Password , Try Again !!!
				</h1>
			</div> 
			<div>
					 <button type="button" class="btn btn-danger btn-block" onclick="location.href = 'login.html';" >Login Again with Correct Password</button>
				</div>
				
<?php
	} ?>
			
	</div>
	</div>
</div>
</body>
</html>
   


     