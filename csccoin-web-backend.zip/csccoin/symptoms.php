

<html>

<head>

<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
    
    <!-- Load jQuery JS -->
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <!-- Load jQuery UI Main JS  -->
    <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    
    <!-- Load SCRIPT.JS which will create datepicker for input field  -->
    <script src="script.js"></script>
	<link rel="stylesheet" href="stylesheet.css" />
	
	  <meta charset='utf-8'>

   <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

  <script type="text/javascript" src="time/jquery.timepicker.js"></script>
  <link rel="stylesheet" type="text/css" href="time/jquery.timepicker.css" />

  <script type="text/javascript" src="time/lib/bootstrap-datepicker.js"></script>
  <link rel="stylesheet" type="text/css" href="time/lib/bootstrap-datepicker.css" />

  <script type="text/javascript" src="time/lib/site.js"></script>
  <link rel="stylesheet" type="text/css" href="time/lib/site.css" />
	  
  
</head>

<body>

<?php

error_reporting( E_ALL );
$pid=$_GET["pid"];

?>
<form method="post" action="submitsymptoms.php">

<br>
	<br>
	<b><p align="center">Choose Date</p>
	<br>
	<input type="text" name="date" id="datepicker">
	<?php 
	echo "
	<input type='hidden' name='pid' value=$pid > ";
	?><br>
	 <article>
         
               <br>
                <p align="center">Set Time</p>
                <p align ="center">
                    <input id="setTimeExample" name="time" type="text" class="time" /><br>
                   
                </p>
        
            <script>
                $(function() {
                    $('#setTimeExample').timepicker();
                             });
            </script>

           </article>
	<br>
	<p align="center">
	   <p align="center"><b>Symptoms</b></p>
<textarea align="center" name="symp" placeholder="Your Symptoms...." rows="5" cols="30">
</textarea>
	<br>
	<br>
	<?php 
	echo "
	<input type='hidden' name='pid' value=$pid > ";
	?>
	<input type=submit class="btn" value="Submit"></input>
	</form>
	<br>

</body>

</html>
